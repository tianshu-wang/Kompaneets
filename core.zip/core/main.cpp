#include <cmath>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

#define _Pi 3.14159265358979323846
using namespace std;

long double * spline_diff(long double x[], long double y[],int n) // Spline interpolation and then calculate derivatives at x
{
    int N=n-1;
    long double b[N],d[N],h[N],a[N];
    long double c[N+1],l[N+1],mu[N+1],z[N+1];
    long double diff[n];

    for(int i=0;i<N;i++)
    {
        h[i]=x[i+1]-x[i];
    }
    for(int i=1;i<N;i++)
    {
        a[i]=3/h[i]*(y[i+1]-y[i])-3/h[i-1]*(y[i]-y[i-1]);
    }
    l[0]=1;
    mu[0]=0;
    z[0]=0;
    for(int i=1;i<N;i++)
    {
        l[i]=2*(x[i+1]-x[i-1])-h[i-1]*mu[i-1];
        mu[i]=h[i]/l[i];
        z[i]=(a[i]-h[i-1]*z[i-1])/l[i];
    }
    l[N]=1;
    c[N]=0;
    z[N]=0;
    for(int j=N-1;j>=0;j--)
    {
        c[j]=z[j]-mu[j]*c[j+1];
        b[j]=(y[j+1]-y[j])/h[j]-h[j]*(c[j+1]-2*c[j])/3;
        d[j]=(c[j+1]-c[j])/3/h[j];
    }
    for(int i=0;i<N;i++)
    {
        diff[i]=b[i];
    }
    diff[N]=b[N-1]+2*c[N-1]*(x[N]-x[N-1])+3*d[N-1]*(x[N]-x[N-1])*(x[N]-x[N-1]);
    return diff;
}

long double f(long double e,long double Tnu,long double r0,long double r1)
{
    long double result;
    result = 0.5*exp(-(e-20)*(e-20)/5/5/2);
    return result;
}


long double q(long double e1,long double e2,long double mu)
{
    long double temp;
    temp = e1*e1+e2*e2-2*e1*e2*mu;
    if(temp<0)
    {
        temp = 0;
    }

    temp=sqrt(temp);
    return temp;
}

long double Q(long double e1,long double e2,long double mu,long double m,long double beta)
{
    long double temp,temp1;
    temp = q(e1,e2,mu);
    if(temp>0)
    {
        temp1 = sqrt(beta*m/2)*(-(e1-e2)/temp+temp/2/m);
    }
    else
    {
        temp1 = -sqrt(beta*m/2);
    }
    return temp1;
}

long double S(long double e1,long double e2,long double mu,long double m,long double nN,int exact,long double beta)
{
    long double temp,temp1,temp2,expeta;
    temp = q(e1,e2,mu);
    temp1 = Q(e1,e2,mu,m,beta);
    expeta = nN/2*sqrt(2*_Pi*beta/m)*(2*_Pi*beta/m);
    if(exact!=1)
    {
        //Approx
        if(temp>0)
        {
            temp2 = nN*sqrt(2*_Pi*beta*m)/temp*exp(-temp1*temp1);
        }
        else
        {
            temp2 = 0;
        }
    }
    else
    {
        //Exact
        if(e1!=e2)
        {
            temp2 = m*m/_Pi/beta/temp/(1-exp(-beta*(e1-e2)))*log((1+exp(-temp1*temp1)*expeta)/(1+exp(-temp1*temp1-beta*(e1-e2))*expeta));
        }
        else
        {
            temp2 = m*m/_Pi/beta/temp*expeta*exp(-temp1*temp1)/(1+expeta*exp(-temp1*temp1));
        }
    }
    return temp2;
}

long double INC(long double e1,long double e2,long double mu,long double m,long double nN,int exact,long double V,long double A,long double beta)
{
    long double temp,temp1;
    temp = S(e1,e2,mu,m,nN,exact,beta);
    temp1 = temp*((1+mu)*V*V+(3-mu)*A*A);
    return temp1;
}

long double intg_mu(long double e1,long double e2,long double m,long double nN,long double V,long double A,int Na,long double pLeg[],long double wLeg[],int exact,long double beta)
{
    long double temp,temp1,mu;
    temp=0.0;
    for(int i=0;i<Na;i++)
    {
        temp1 = INC(e1,e2,pLeg[i],m,nN,exact,V,A,beta);
        temp += 2*_Pi*temp1*wLeg[i];
    }
    return temp;
}

void StructureFunction(long double beta,int Npoint,int Na,int Nstep,long double dt,long double ratio,long double Ye,long double G2,long double nN,long double m,int exact,long double Tnu,long double r0,long double r1,int IsDepE)
{
    string line;
    long double Vp=-0.5*(1-4*0.23122),Ap=-1.2723/2,Vn=-0.5*1,An=-1.2723/2;
    long double values[Npoint],depE[Npoint];
    long double pLeg[Na],wLeg[Na],pLag[Npoint],wLag[Npoint];
    long double temp,temp1;

    long double M2[Npoint][Npoint];


    ifstream fLegendre("result/leg-"+to_string(Na)+".txt");
    int ipoint;
    if(fLegendre.is_open())
    {
        ipoint=0;
        while(getline(fLegendre,line))
        {
           istringstream in(line);
           in >> temp >>temp1;
           pLeg[ipoint] = temp;
           wLeg[ipoint] = temp1;
           ipoint++;
        }
        fLegendre.close();
    }
    ifstream fLaguerre("result/lag-"+to_string(Npoint)+".txt");
    long double es[Npoint];
    if(fLaguerre.is_open())
    {
        ipoint=0;
        while(getline(fLaguerre,line))
        {
           istringstream in(line);
           in >> temp >> temp1;
           pLag[ipoint] = temp;
           wLag[ipoint] = temp1*exp(temp);
           es[ipoint] = temp*ratio;
           ipoint++;
        }
        fLaguerre.close();
    }

    for(int i1=0;i1<Npoint;i1++)
    {
            values[i1] = f(es[i1],Tnu,r0,r1);
    }


    for(int i1=0;i1<Npoint;i1++)
    {
            for(int i2=0;i2<Npoint;i2++)
            {
                    M2[i1][i2] = ratio*wLag[i2]*es[i2]*es[i2]*(intg_mu(es[i1],es[i2],m,Ye*nN,Vp,Ap,Na,pLeg,wLeg,exact,beta)+intg_mu(es[i1],es[i2],m,nN*(1-Ye),Vn,An,Na,pLeg,wLeg,exact,beta))*G2;
                
            }
    }

    long double delta[Npoint];
    int percent=1;
    long double total=0,temptotal=0,factor=1;
    ofstream input;
    if(exact==1)
    {
        input.open("result/0-exact.txt");
    }
    else
    {
        input.open("result/0.txt");
    }
    for(int i=0;i<Npoint;i++)
    {
            input <<values[i] << endl;
    }
    input.close();
    ofstream intermediate;
    ofstream depEtemp;
    ofstream depNtemp;
    for(int iter=0;iter<Nstep;iter++)
    {
        for(int i1=0;i1<Npoint;i1++)
        {
                temp = 0.0;
                depE[i1] = 0.0;
                for(int i2=0;i2<Npoint;i2++)
                {
                        temp += M2[i1][i2]*(exp(beta*(es[i2]-es[i1]))*values[i2]*(1-values[i1])-values[i1]*(1-values[i2]))/(2.0*_Pi)/(2.0*_Pi)/(2.0*_Pi);
                        //depE[i1] += M2[i1][i2]*(exp(beta*(es[i2]-es[i1]))*values[i2]*(1-values[i1])-values[i1]*(1-values[i2]))/(2.0*_Pi)/(2.0*_Pi)/(2.0*_Pi)*es[i1];
                        depE[i1] += M2[i1][i2]*(exp(beta*(es[i2]-es[i1]))*values[i2]*(1-values[i1])-values[i1]*(1-values[i2]))/(2.0*_Pi)/(2.0*_Pi)/(2.0*_Pi)*(es[i1]-es[i2])/2;
                }
                delta[i1] = temp*dt;
        }
        if(iter==0)
        {
            if(exact==1)
            {
                depEtemp.open("result/0-exact-depE.txt");
                depNtemp.open("result/0-exact-depN.txt");
            }
            else
            {
                depEtemp.open("result/0-depE.txt");
                depNtemp.open("result/0-depN.txt");
            }
            for(int i=0;i<Npoint;i++)
            {
                    depEtemp  <<es[i]<<" "<<depE[i] << endl;
                    depNtemp  <<es[i]<<" "<<delta[i]/dt << endl;
            }
            depEtemp.close();
            depNtemp.close();
        }
        if(IsDepE==1)
        {
            return;
        }
        for(int i1=0;i1<Npoint;i1++)
        {
                values[i1] += delta[i1];   
        }

        if(100*(iter)>percent*Nstep||iter==Nstep-1)
        {
            cout << percent << "/100" <<endl;
            if(exact==1)
            {
                intermediate.open("result/"+to_string(percent)+"-exact.txt");
                depEtemp.open("result/"+to_string(percent)+"-exact-depE.txt");
                depNtemp.open("result/"+to_string(percent)+"-exact-depN.txt");
            }
            else
            {
                intermediate.open("result/"+to_string(percent)+".txt");
                depEtemp.open("result/"+to_string(percent)+"-depE.txt");
                depNtemp.open("result/"+to_string(percent)+"-depN.txt");
            }
            for(int i=0;i<Npoint;i++)
            {
                    intermediate  <<values[i] << endl;
                    depEtemp  <<es[i]<<" "<<depE[i] << endl;
                    depNtemp  <<es[i]<<" "<<delta[i]/dt << endl;
            }
            intermediate.close();
            depEtemp.close();
            depNtemp.close();
            percent += 1;
        }
    }
}


void kompaneets(long double beta,long double upper,int Npoint,int Nstep,long double dt,long double Ye,long double G2,long double nN,long double m,int Na,long double Tnu,long double r0,long double r1,int IsDepE,int usenew,long double MinE) //Logrithmic sampling
{
    long double Vp=-0.5*(1-4*0.23122),Ap=-1.2723/2,Vn=-0.5*1,An=-1.2723/2;
    long double xs[Npoint],es[Npoint],Jnu[Npoint],x3J[Npoint],dx3J[Npoint-1],flux[Npoint+1],depE[Npoint+1],deltax3J[Npoint],weight[Npoint],Inu[Npoint+1];
    long double x,lowerx,upperx,dlnx,temp;

    lowerx = MinE*beta;
    upperx = upper*beta;
    dlnx = (log(upperx)-log(lowerx))/(Npoint-1);
    for(int i=0;i<Npoint;i++)
    {
        xs[i] = exp(dlnx*i)*lowerx;
        es[i] = xs[i]/beta;
        Jnu[i] = f(es[i],Tnu,r0,r1);
        weight[i]=xs[i]*xs[i]*xs[i];
    }


    ofstream input;
    input.open("result/0-kom.txt");
    for(int i=0;i<Npoint;i++)
    {
        input << es[i] <<" "<<Jnu[i]<<endl;
    }
    input.close();


    for(int i=0;i<Npoint;i++)
    {
        x3J[i] = Jnu[i]*weight[i];
    }

    int percent=1;
    ofstream intermediate;
    ofstream depEtemp;
    ofstream depNtemp;
    long double temp1,temp2,itpx3J[Npoint-1],fn,fp,factor;
    temp1 = lowerx*exp(-dlnx);
    temp1 = temp1*temp1*temp1*f(temp1/beta,Tnu,r0,r1);
    temp2 = lowerx*exp(Npoint*dlnx);
    temp2 = temp2*temp2*temp2*f(temp2/beta,Tnu,r0,r1);
    for(int iter=0;iter<Nstep;iter++)
    {
        flux[0]=0;
        flux[Npoint]=0;
        Inu[0]=0;
        depE[Npoint]=0;
        for(int i=0;i<Npoint-1;i++)
        {
            //4-point derivative
            itpx3J[0] = exp((9*(log(x3J[1])+log(x3J[0]))-(log(x3J[2])+log(temp1)))/16);
            itpx3J[Npoint-2] = exp((9*(log(x3J[Npoint-1])+log(x3J[Npoint-2]))-(log(temp2)+log(x3J[Npoint-3])))/16);
            dx3J[0] = (27*(log(x3J[1])-log(x3J[0]))-(log(x3J[2])-log(temp1)))/24/dlnx*itpx3J[0];
            dx3J[Npoint-2] = (27*(log(x3J[Npoint-1])-log(x3J[Npoint-2]))-(log(temp2)-log(x3J[Npoint-3])))/24/dlnx*itpx3J[Npoint-2];
            if(i>0&&i<Npoint-2)
            {
                itpx3J[i] = exp((9*(log(x3J[i+1])+log(x3J[i]))-(log(x3J[i+2])+log(x3J[i-1])))/16);
                dx3J[i] = (27*(log(x3J[i+1])-log(x3J[i]))-(log(x3J[i+2])-log(x3J[i-1])))/24/dlnx*itpx3J[i];
            }
        }
        
        for(int i=0;i<Npoint-1;i++)
        {
                x=sqrt(xs[i]*xs[i+1]);
                if(usenew==0)
                {
                //normal
                factor= 0.;
                flux[i+1] = (x*x*dx3J[i]-3*x*x*itpx3J[i]+x*x*x*itpx3J[i]-itpx3J[i]*itpx3J[i])*((Vp*Vp+5*Ap*Ap)*Ye+(Vn*Vn+5*An*An)*(1-Ye));
                temp = (x*x*dx3J[i]-3*x*x*itpx3J[i]+x*x*x*itpx3J[i]-itpx3J[i]*itpx3J[i])*((Vp*Vp+5*Ap*Ap)*Ye+(Vn*Vn+5*An*An)*(1-Ye))*(1-factor);
                }
                if(usenew==1)
                {
                //new
                fp = ((4*x-14)*Vp*Vp+(28*x-86)*Ap*Ap)/(Vp*Vp+5*Ap*Ap)/beta/m;
                fn = ((4*x-14)*Vn*Vn+(28*x-86)*An*An)/(Vn*Vn+5*An*An)/beta/m;
                flux[i+1] = (x*x*dx3J[i]-3*x*x*itpx3J[i]+x*x*x*itpx3J[i]-itpx3J[i]*itpx3J[i])*((Vp*Vp+5*Ap*Ap)*Ye*(1-fp)+(Vn*Vn+5*An*An)*(1-Ye)*(1-fn));
                temp = (x*x*dx3J[i]-3*x*x*itpx3J[i]+x*x*x*itpx3J[i]-itpx3J[i]*itpx3J[i])*((Vp*Vp+5*Ap*Ap)*Ye*(1-fp)+(Vn*Vn+5*An*An)*(1-Ye)*(1-fn));
                }
                if(usenew==2)
                {
                //recoil
                fp = (2*Vp*Vp+14*Ap*Ap)*x/(Vp*Vp+5*Ap*Ap)/beta/m; //recoil
                fn = (2*Vn*Vn+14*An*An)*x/(Vn*Vn+5*An*An)/beta/m; //recoil
                flux[i+1] = (x*x*dx3J[i]-3*x*x*itpx3J[i]+x*x*x*itpx3J[i]-itpx3J[i]*itpx3J[i])*((Vp*Vp+5*Ap*Ap)*Ye*(1-fp)+(Vn*Vn+5*An*An)*(1-Ye)*(1-fn));
                temp = (x*x*dx3J[i]-3*x*x*itpx3J[i]+x*x*x*itpx3J[i]-itpx3J[i]*itpx3J[i])*((Vp*Vp+5*Ap*Ap)*Ye*(1-fp)+(Vn*Vn+5*An*An)*(1-Ye)*(1-fn));
                }
                Inu[i+1] = temp;
        }
        long double xs1[Npoint+1],xInu[Npoint+1],* dxInu;
        xs1[Npoint]=es[Npoint-1]*exp(dlnx*0.5);
        xInu[Npoint]=0;
        for(int i=0;i<Npoint;i++)
        {
            xs1[i]=es[i]*exp(-dlnx*0.5);
            xInu[i]=xs1[i]*Inu[i];
        }
        dxInu=spline_diff(xs1,xInu,Npoint+1);

        for(int i=0;i<Npoint;i++)
        {   
            Inu[i] = Inu[i];
            depE[i] = -2*G2*nN/3/_Pi/beta/beta/beta/beta/m*Inu[i]/xs1[i]/xs1[i]/beta/beta;
            deltax3J[i] = dt*2*G2*nN/3/_Pi/beta/beta/beta/m*(flux[i+1]-flux[i])/dlnx;
        }
        for(int i=0;i<Npoint;i++)
        {
            x3J[i] += deltax3J[i];
            Jnu[i] = x3J[i]/weight[i];
        }
        if(iter==0)
        {
            depEtemp.open("result/0-kom-depE.txt");
            depNtemp.open("result/0-kom-depN.txt");
            for(int i=0;i<Npoint;i++)
            {
                depEtemp  <<es[i]*exp(-dlnx*0.5) <<" "<<depE[i]<<endl;
                depNtemp  << es[i]<<" "<<deltax3J[i]/dt/weight[i]<<endl;
            }
            depEtemp.close();
            depNtemp.close();
        }
        if(IsDepE==1)
        {
            return;
        }


        if(100*iter>percent*Nstep||iter==Nstep-1)
        {
            cout << percent << "/100" <<endl;
            intermediate.open("result/"+to_string(percent)+"-kom.txt");
            depEtemp.open("result/"+to_string(percent)+"-kom-depE.txt");
            depNtemp.open("result/"+to_string(percent)+"-kom-depN.txt");
            for(int i=0;i<Npoint;i++)
            {
                intermediate  <<es[i] << " "<<Jnu[i]<<endl;
                depEtemp  <<es[i]*exp(-dlnx*0.5) <<" "<<depE[i]<<endl;
                depNtemp  << es[i]<<" "<<deltax3J[i]/dt/weight[i]<<endl;
            }
            intermediate.close();
            depEtemp.close();
            depNtemp.close();
            percent += 1;
        }

    }
   
}

extern "C"
{
void * kom(long double beta,long double upper,int Npoint,int Nstep,long double dt,long double Ye,long double G2,long double nN,long double m,int Na,long double Tnu,long double r0,long double r1,int IsDepE,int usenew,long double MinE)
{
    kompaneets(beta,upper,Npoint,Nstep,dt,Ye,G2,nN,m,Na,Tnu,r0,r1,IsDepE,usenew,MinE);
}

void * SF(long double beta,int Npoint,int Na,int Nstep,long double dt,long double ratio,long double Ye,long double G2,long double nN,long double m,int exact,long double Tnu,long double r0,long double r1,int IsDepE)
{
    StructureFunction(beta,Npoint,Na,Nstep,dt,ratio,Ye,G2,nN,m,exact,Tnu,r0,r1,IsDepE);
}

}
